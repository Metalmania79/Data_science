SELECT * FROM Orders;

UPDATE Orders
SET Quantity = 5
WHERE OrderID = 1