SELECT *
FROM Customers;

DELETE FROM Customers
WHERE CustomerID = 1001;

SELECT *
FROM Orders;