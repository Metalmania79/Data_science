SELECT CustomerID, FirstName, LastName, Address, City, State 
FROM Red30Tech.dbo.Customers;

SELECT FirstName, LastName
FROM dbo.Customers;

SELECT State, City, FirstName, LastName
FROM dbo.Customers;

SELECT TOP (3) State, City, FirstName, LastName
FROM dbo.Customers;

SELECT * 
FROM dbo.Customers;