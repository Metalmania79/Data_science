CREATE TABLE ProductCategories (
	CategoryID int IDENTITY(1,1) NOT NULL,
	CategoryName varchar(25) NOT NULL,
	CategoryAbbreviation char(2) NOT NULL
);