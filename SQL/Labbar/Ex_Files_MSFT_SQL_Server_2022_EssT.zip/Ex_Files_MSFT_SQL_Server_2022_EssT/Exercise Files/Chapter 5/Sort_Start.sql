SELECT CustomerID, FirstName, LastName, Address, City, State 
FROM dbo.Customers
;