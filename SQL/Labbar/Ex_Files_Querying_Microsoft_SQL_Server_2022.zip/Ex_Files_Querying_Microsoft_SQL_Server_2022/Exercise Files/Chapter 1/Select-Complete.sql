SELECT *
FROM HumanResources.Department;