SELECT *
FROM HumanResources.Department

;