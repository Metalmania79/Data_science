SELECT Name AS 'Department Name',
	GroupName AS 'Management Group'
FROM HumanResources.Department;