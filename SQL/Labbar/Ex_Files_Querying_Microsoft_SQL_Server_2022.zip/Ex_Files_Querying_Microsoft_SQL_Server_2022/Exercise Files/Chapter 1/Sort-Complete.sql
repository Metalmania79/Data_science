SELECT *
FROM HumanResources.Department
ORDER BY GroupName DESC, DepartmentID
;