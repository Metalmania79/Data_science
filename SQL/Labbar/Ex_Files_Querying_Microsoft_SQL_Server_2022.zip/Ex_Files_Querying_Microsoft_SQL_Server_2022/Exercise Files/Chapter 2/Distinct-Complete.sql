SELECT DISTINCT City, StateProvinceID
FROM Person.Address
ORDER BY City;