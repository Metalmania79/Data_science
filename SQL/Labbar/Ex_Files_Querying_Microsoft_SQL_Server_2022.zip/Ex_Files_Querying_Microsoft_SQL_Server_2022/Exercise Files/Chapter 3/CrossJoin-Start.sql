SELECT Department.Name
FROM HumanResources.Department;

SELECT AddressType.Name
FROM Person.AddressType;